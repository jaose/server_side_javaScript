const _ = require('underscore');
//配列を簡単に使えるように手伝うlib
const arr = [3, 6, 9, 1, 12];
console.log(arr[0]);
console.log(_.first(arr));
console.log(arr[arr.length - 1]);
console.log(_.last(arr));